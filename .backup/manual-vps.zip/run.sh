gnome-terminal -- bash -c "./playit; exec bash"

# Mở terminal mới chạy proxy.py
gnome-terminal -- bash -c "python3 proxy.py; exec bash"
